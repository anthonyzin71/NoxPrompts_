# NoxPrompts · Gerador Pro

## Estrutura do projeto

```
noxprompts/
├── api/
│   └── generate.js      ← proxy serverless (esconde a API key)
├── public/
│   └── index.html       ← o app frontend
├── vercel.json          ← configuração da Vercel
├── .env.example         ← template de variáveis de ambiente
└── .gitignore
```

## Deploy na Vercel (passo a passo)

### 1. Instale a CLI da Vercel
```bash
npm install -g vercel
```

### 2. Faça login
```bash
vercel login
```

### 3. Suba o projeto pela primeira vez
```bash
cd noxprompts
vercel
```
Responda as perguntas:
- Set up and deploy? **Y**
- Which scope? escolha sua conta
- Link to existing project? **N**
- Project name? **noxprompts** (ou o nome que quiser)
- In which directory? **.** (ponto, pasta atual)

### 4. Configure a variável de ambiente

Na dashboard da Vercel (vercel.com) → seu projeto → **Settings → Environment Variables**:

| Name | Value |
|------|-------|
| `ANTHROPIC_API_KEY` | `sk-ant-sua-chave-aqui` |
| `ALLOWED_ORIGIN` | `https://seudominio.com.br` (ou deixe vazio em dev) |

**Importante:** após adicionar as variáveis, faça um novo deploy:
```bash
vercel --prod
```

### 5. Domínio personalizado (opcional)
Na dashboard: **Settings → Domains** → adicione seu domínio.

---

## Desenvolvimento local

```bash
# Crie o arquivo de variáveis locais
cp .env.example .env.local
# Edite e coloque sua chave real
nano .env.local

# Rode localmente com a CLI da Vercel (simula as serverless functions)
vercel dev
```

O app estará disponível em `http://localhost:3000`.

---

## Rate limiting

O proxy bloqueia IPs que façam mais de **10 requisições por minuto**.
Para produção com alto volume, substitua o `rateMap` em `api/generate.js`
por [Upstash Redis](https://upstash.com) ou [Vercel KV](https://vercel.com/docs/storage/vercel-kv).
